fx_version 'cerulean'
game 'gta5'

author 'Itzz.Ado'
description '/lobby teleport'
version '1.0'

client_script 'client.lua'
-- Upozornění:
-- Tento skript je vlastnictvím Itzz.Ado.
-- Jakékoli kopírování, úpravy nebo redistribuce bez souhlasu autora jsou zakázány.
-- Pokud máš zájem připoj se zde: https://discord.gg/x59sd97Qvm