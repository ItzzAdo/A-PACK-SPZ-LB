RegisterCommand('lobby', function()
    local ped = PlayerPedId()

    if not IsEntityDead(ped) then
        notify('Teleportuješ se do lobby...')
        Wait(3000)

        SetEntityCoords(ped, 1605.0731, 3603.2844, 35.1463, false, false, false, true)
        SetEntityHeading(ped, 90.0)

        notify('Byl jsi teleportován do lobby!')
    else
        notify('Nemůžeš použít lobby, když jsi mrtvý.')
    end
end)

function notify(text)
    SetNotificationTextEntry('STRING')
    AddTextComponentString(text)
    DrawNotification(false, true)
end
